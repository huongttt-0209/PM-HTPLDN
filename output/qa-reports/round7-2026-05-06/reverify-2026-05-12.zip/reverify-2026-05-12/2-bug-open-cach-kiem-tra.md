# Hướng dẫn kiểm tra 2 bug đang Open — R25 reverify

**Ngày:** 2026-05-16 10:30:00
**Mục đích:** Hướng dẫn người dùng cuối kiểm tra lại 2 bug còn Open trên web không cần thao tác kỹ thuật.

**Thông tin chung:**
- URL: http://103.172.236.130:3000/
- OTP login: gõ `666666` (dev bypass)
- File bug-report gốc nằm trong `bug-reports/danh-gia/` và `bug-reports/vu-viec/`

> **R25 update 2026-05-16 10:30:00:** Sau R25 verify, **1 bug đã đóng** (BUG-FUNC-DG-013 — cả BE + FE đã align spec, xem mục cuối) → còn lại **2 bug Open**: BUG-VV-PC-WRN-01 + BUG-VV-FN-LICHSU-01.

---

## Bug 1 — BUG-VV-PC-WRN-01

### Thông tin nhanh

| Trường | Giá trị |
|---|---|
| Module | **Quản lý Vụ việc HTPL** |
| Màn hình | Detail vụ việc → Modal **"Phân công tư vấn viên"** |
| Severity | **Minor P2** |
| Trạng thái | Open — chờ dev quyết cách cho phép tìm TVV ngoài lĩnh vực |
| R25 verify | 2026-05-16 — re-confirm Open, BE+FE chưa fix |

### Bug là gì (dễ hiểu)

- Cán bộ nghiệp vụ tạo 1 vụ việc thuộc lĩnh vực **"Doanh nghiệp"** → bấm Phân công → tìm tư vấn viên.
- Hệ thống chỉ hiện TVV có lĩnh vực **"Doanh nghiệp"**.
- Nếu không có TVV nào phù hợp, web hiện popup **"Liên hệ QTHT để mở rộng lĩnh vực TVV/NHT, hoặc chọn vụ việc khác"** → cán bộ bị kẹt.
- Spec yêu cầu cho cán bộ một **cách để tìm tư vấn viên thuộc lĩnh vực khác** (vd nút "Tìm thủ công", hoặc bỏ filter lĩnh vực).
- Hiện tại web không có nút nào để vượt qua tình huống này → vụ việc đó không phân công được.

### Cách kiểm tra trên web

**Account cần dùng:** `cb_nv_tw_01` / `Secret@123` (cán bộ Trung ương — có quyền phân công).

1. Login `cb_nv_tw_01` + OTP `666666`.
2. Sidebar → **"Quản lý vụ việc HTPL"** → danh sách vụ việc.
3. Tìm 1 vụ việc thuộc lĩnh vực **"Doanh nghiệp"** state **"Đang kiểm tra"** (vd `VV-QA-R7-PRIVACY-DNAG002`). Nếu không có, dùng cách dưới đây tạo mới:
   - Click **[Tạo vụ việc mới]** → fill: Doanh nghiệp = bất kỳ, Lĩnh vực = **Doanh nghiệp**, Loại hình = Tư vấn pháp luật → Lưu.
   - Mở detail vụ việc vừa tạo → click **[Kiểm tra hồ sơ]** → **[Xác nhận]** (state chuyển sang "Đang kiểm tra").
4. Click nút **[Phân công]** ở thanh action bar → modal "Phân công tư vấn viên" mở.
5. Click dropdown **"Chọn người được phân công"** → quan sát danh sách.
6. Gõ vào ô search trong dropdown: `XXKHONGMATCH99` (chuỗi bừa để force empty).

### Kết quả thấy được (R25 2026-05-16)

- Modal có: radio **Cá nhân**/**Tổ chức tư vấn** + 1 dropdown chọn người + 1 ô **Ghi chú** + 2 nút **[Hủy]** / **[Xác nhận]**.
- Empty state hiện text: **"Trống / Không tìm thấy đối tượng phù hợp lĩnh vực / Liên hệ QTHT để mở rộng lĩnh vực TVV/NHT, hoặc chọn vụ việc khác."**.
- ❌ **KHÔNG có nút [Tìm thủ công]** hoặc nút bỏ filter lĩnh vực.
- ❌ Gõ tên TVV thật ở lĩnh vực khác (vd `hương`) → vẫn 0 kết quả (dù TVV "hương tvv1" tồn tại trong hệ thống).

### Khi nào coi là FIXED

- Modal phân công có thêm 1 trong các cơ chế: nút **[Tìm thủ công]**, hoặc **toggle bỏ filter lĩnh vực**, hoặc **dropdown thứ 2 không lọc lĩnh vực**.
- Cán bộ chọn được TVV thuộc lĩnh vực khác.

---

## Bug 2 — BUG-VV-FN-LICHSU-01

### Thông tin nhanh

| Trường | Giá trị |
|---|---|
| Module | **Quản lý Vụ việc HTPL** |
| Màn hình | Detail vụ việc → tab **"Dòng thời gian"** (hoặc accordion "Lịch sử hành động") |
| Severity | **Minor P3** |
| Trạng thái | Open (chỉ còn legacy backfill — vụ việc CŨ trước fix) |
| R25 verify | 2026-05-16 — FE i18n fresh data giữ vững ✓, legacy VV chưa fix |

### Bug là gì (dễ hiểu)

- Mỗi vụ việc có 1 tab "Dòng thời gian" hiện lịch sử các hành động (ai làm gì, lúc nào).
- Spec yêu cầu hệ thống ghi đầy đủ 18 loại hành động riêng biệt (Tạo vụ việc, Tiếp nhận, Kiểm tra, Yêu cầu bổ sung, Phân công, Phê duyệt, Hoàn thành, Đánh giá, …).
- **R25 tin tốt cho vụ việc mới:** vụ việc tạo gần đây → BE ghi đúng loại hành động + UI hiện đúng tiếng Việt (vd "Yêu cầu bổ sung", "Tạo vụ việc", "Phân công", "Kiểm tra"). FE đã thêm i18n mapping.
- **Tin chưa tốt cho vụ việc cũ:** vụ việc cũ (trước khi sửa) vẫn lưu hành động dạng "UPDATE" / "CREATE" generic. UI **ẩn hoàn toàn** các entry UPDATE → người xem chỉ thấy 1 entry "Tạo mới", không thấy các bước chuyển trạng thái về sau.

### Cách kiểm tra trên web

**Account cần dùng:** `cb_nv_tw_01` (hoặc `cb_nv_tw_03`) / `Secret@123`.

1. Login + OTP `666666`.
2. Sidebar → **"Quản lý vụ việc HTPL"**.

**Test A — Vụ việc MỚI (kỳ vọng PASS ✓):**

3. Mở vụ việc fresh trạng thái "Yêu cầu bổ sung" — vd UUID `4a1a6889-97f8-4744-afcd-75aaa1d558a9` (`VV-BTP-TW-20260514-001`).
4. Cuộn xuống mục **"Dòng thời gian"**.
5. ✅ Thấy 2 entries: **"Yêu cầu bổ sung"** (kèm thời gian + tên cán bộ) + **"Tạo vụ việc"** → ĐÚNG spec.

**Test B — Vụ việc CŨ (kỳ vọng FAIL ❌ — bug):**

6. Mở vụ việc legacy trạng thái "Yêu cầu bổ sung" — vd UUID `33b5a612-56c9-4e8b-82dc-109ca806944f` (`VV-BTP-TW-20260509-002`).
7. Cuộn xuống mục **"Dòng thời gian"**.
8. ❌ Chỉ thấy **1 entry "Tạo mới"** dù vụ việc đã đi qua 2 bước (KIEM_TRA → YEU_CAU_BO_SUNG). 2 bước UPDATE bị giấu.

### Kết quả thấy được (R25 2026-05-16)

- Vụ việc MỚI → timeline render đúng tên hành động tiếng Việt ✓.
- Vụ việc CŨ → 2 entry UPDATE bị ẩn → user mất thông tin lịch sử.

### Khi nào coi là FIXED

Dev chọn 1 trong 2 cách:
- (a) **BE migrate** dữ liệu cũ — đổi `UPDATE`/`CREATE` sang tên hành động canonical tương ứng (TAO_VV, KIEM_TRA, YEU_CAU_BO_SUNG, …) theo trạng thái sau.
- (b) **FE fallback** — khi gặp enum lạ (UPDATE/CREATE), FE hiện label suy từ "trạng thái sau" (vd UPDATE+state YEU_CAU_BO_SUNG → label "Yêu cầu bổ sung").

Sau fix: vụ việc cũ (vd `VV-BTP-TW-20260509-002`) → timeline hiện đủ entries với label đúng (Tạo vụ việc / Kiểm tra / Yêu cầu bổ sung), không còn entry "Cập nhật" generic hoặc bị ẩn.

---

## Tóm tắt 2 bug Open

| Bug | Module | Màn hình | Account | Bước nhanh |
|---|---|---|---|---|
| BUG-VV-PC-WRN-01 | Vụ việc | Modal Phân công TVV | `cb_nv_tw_01` | Mở VV LV Doanh nghiệp → Phân công → search bừa → xem có nút override không |
| BUG-VV-FN-LICHSU-01 | Vụ việc | Tab Dòng thời gian | `cb_nv_tw_01` | Mở VV CŨ trạng thái "Yêu cầu bổ sung" → timeline chỉ có 1 entry "Tạo mới" |

**Cả 2 bug đều là Minor**, không block nghiệp vụ chính — chỉ là UX (Bug 1) / audit log legacy (Bug 2). Dev fix xong sẽ retest.

---

## Bug đã đóng R25 (tham khảo)

### ~~BUG-FUNC-DG-013~~ — Đã đóng 2026-05-16 R25 ✅

| Trường | Giá trị |
|---|---|
| Module | **Đánh giá hiệu quả HTPL** |
| Severity gốc | Minor P3 (đã downgrade từ Major P1) |
| Trạng thái | ✅ **Closed-verified** |
| R25 verify | 2026-05-16 10:15:00 — cả BE + FE đã align spec |

**R25 fresh probe** (`cb_nv_dp_02` STP-BG, cross-cơ quan, KH `440b6dd1-...` của STP-AG):
- API 3/3 endpoint `/ke-hoach-danh-gias/{id}` + `/bao-cao` + `/ket-quas` đều trả `HTTP 403 + ERR-DG-10 + message: "Bạn không có quyền xem kết quả đánh giá này"` đúng nguyên văn spec.
- FE auto-redirect `/403` render đúng câu **"Bạn không có quyền xem kết quả đánh giá này"** + **"Mã lỗi: ERR-DG-10"** + "Vai trò hiện tại: CB_NV_DP". KHÔNG còn câu generic "Bạn không có quyền truy cập trang này".

Bug đóng hoàn toàn — file bug-report đã rename `Pass-bug-report-r22-fr-vi-10.md`.
